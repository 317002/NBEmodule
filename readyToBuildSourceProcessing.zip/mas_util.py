#!/usr/bin/python
#
# MODULE: mas_util
#
# PURPOSE: General purpose utilities
#
# MODIFICATION HISTORY:
# '13Nov06       Created by Mark Stanley
# '14Jan03       Added 'mas_calc_elev'
# '14Mar23       Added 'mas_cart2sphere()'
# '14Nov22       Added 'mas_get_earth_radius()'
# '14Nov25       Added 'mas_get_ECEF_from_geodetic()'
# '14Dec01       Added 'mas_find_arc_intersection()'
# '15Mar07       Added 'mas_get_ENU_from_geodetic()'
# '16Apr04       Added 'mas_get_AER_from_ENU()'


####  IMPORTS  ####

import numpy as np
import os


####  FUNCTIONS  ####

def mas_append_separator( path ):
    """ Appends the OS path separator, if not already present, to the
        specified string.  The new string is returned to the caller.
    """

    if (path[-1] != os.path.sep):
        path += os.path.sep

    return  path


def mas_calc_elev( r_i, zObj, zObs, isDegrees=True ):
    """ Calculates elevation angles given arc-distance range(s) [km]
        along the surface of the Earth, target height [km] MSL, and
        the observer's height [km] MSL.
    """

    Re = 6371.
    alpha_i = r_i / Re
    cosAlpha_i = np.cos( alpha_i )

    # Calculate length of sides of oblique triangle (sides join
    #  center of earth, observer and object)
    a = Re + zObs
    c = Re + zObj
    b = (a*a + c*c - 2*a*c*cosAlpha_i)**0.5

    # Elevation angles (radians):
    el_i = np.arccos( (a - c*cosAlpha_i) / b ) - np.pi/2.

    # Convert to degrees, if requested:
    if isDegrees:
        el_i = np.rad2deg( el_i )

    return  el_i


def mas_cart2sphere( x_i, y_i, z_i ):
    """Converts cartesian (x,y,z) coordinates to spherical coordinates
    of azimuth, elevation and radius.  The azimuth and elevation
    angles returned to the caller will be in radians.

    USAGE:  az_i, el_i, r_i = mas_cart2sphere( x_i, y_i, z_i )
    """

    r_i  = np.sqrt( np.square(x_i) + np.square(y_i) + np.square(z_i) )
    el_i = np.arcsin( z_i / r_i )
    az_i = np.arctan2( y_i , x_i )

    return  (az_i, el_i, r_i)


def mas_find_arc_intersection( xa_i, ya_i, za_i, xb_i, yb_i, zb_i ):
    """Locates where two sets of cartesian points are closest to each
    other and returns: midpoint at closest approach (x/y/z) AND
    distance of closest approach.  For this procedure to work
    properly, the points must be reasonably behaved (multiple "close
    approaches" may not be properly handled)

    USAGE:  x, y, z, d = mas_find_arc_intersection( xa_i, ya_i, za_i, \
                                                    xb_i, yb_i, zb_i )

    MODIFICATION HISTORY:
    '14Dec01        Created using 'tool_findArcIntersection()' in
                     'tool.pro' as a template
    """

    # Number of points per set
    numA = len( xa_i )
    numB = len( xb_i )

    # Initialize lower/upper points of examined region to entire set
    ia0 = 0
    ib0 = 0
    ia1 = numA - 1
    ib1 = numB - 1

    # Number of slices to check each iteration (note: this affects
    #  how rapidly a solution is converged upon):
    numSlice = 100.

    # Initial increment sizes:
    incA = numA / numSlice
    incB = numB / numSlice

    # Repeat until bracket minimum separation to a single point:
    while ((ia1 - ia0) > 2) or ((ib1 - ib0) > 2):
        # Indices in set A to check this iteration:
        if incA > 1:
            subNumA = np.floor( (ia1 - ia0) / incA ).astype(np.uint64)
        else:
            # If index increment is <1, check all remaining points:
            subNumA = ia1 - ia0 + 1
            incA    = 1.
        iSubA_i = ia0 + np.round( incA * np.arange( subNumA )).astype(np.uint64)

        # ...set B:
        if incB > 1:
            subNumB = np.floor( (ib1 - ib0) / incB ).astype(np.uint64)
        else:
            subNumB = ib1 - ib0 + 1
            incB    = 1.
        iSubB_i = ib0 + np.round( incB * np.arange( subNumB )).astype(np.uint64)

        # Compute the square of the distances between the subsets:
        sqrDist_i = np.zeros( subNumA * subNumB )
        for iNumA in range( subNumA ):
            iSubA = iSubA_i[iNumA]
            sqrDist_i[iNumA*subNumB:(iNumA+1)*subNumB] = \
                ( xa_i[iSubA] - xb_i[iSubB_i] )**2 + \
                ( ya_i[iSubA] - yb_i[iSubB_i] )**2 + \
                ( za_i[iSubA] - zb_i[iSubB_i] )**2

        # Determine the index of the minimum distance (squared) -and-
        #  the value of that distance
        iSubMin    = np.argmin( sqrDist_i )
        minSqrDist = sqrDist_i[iSubMin]
        iSubMinA = np.floor( iSubMin / subNumA ).astype(np.uint64)
        iSubMinB = iSubMin - (iSubMinA * subNumA)

        # Convert subset indices to full indices
        iMinA = ia0 + np.round( iSubMinA * incA ).astype(np.uint64)
        iMinB = ib0 + np.round( iSubMinB * incB ).astype(np.uint64)

        # Set new lower/upper bounds, centered on subset minimum distance point
        ia0 = np.round( iMinA - incA ).astype(np.uint64)
        if (ia0 < 0):
            ia0 = 0
        ia1 = np.round( iMinA + incA ).astype(np.uint64)
        if (ia1 >= numA):
            ia1 = numA - 1

        ib0 = np.round( iMinB - incB ).astype(np.uint64)
        if (ib0 < 0):
            ib0 = 0
        ib1 = np.round( iMinB + incB ).astype(np.uint64)
        if (ib1 >= numB):
            ib1 = numB - 1

        # Calculate new increments
        incA = (ia1 - ia0) / numSlice
        incB = (ib1 - ib0) / numSlice

    # Determine the location of the midpoint at minimum separation
    xMid = (xa_i[iMinA] + xb_i[iMinB]) / 2.
    yMid = (ya_i[iMinA] + yb_i[iMinB]) / 2.
    zMid = (za_i[iMinA] + zb_i[iMinB]) / 2.

    # ...and the distance of minimum separation
    d = np.sqrt( minSqrDist )

    # Return values to caller
    return  xMid, yMid, zMid, d


def mas_get_AER_from_ENU( x_i, y_i, z_i ):
	""" Determines the Azimuth, Elevation and Range to cartesian coordinates provided in the
	East (x), North (y) and Up (z) local coordinate frame.  Azimuth and elevation angles will be
	output in units of degrees while the range will be in the same units as x/y/z (probably
	meters).   The azimuth angle is defined as clockwise from north, ranging from 0 to 360
	degrees.

	MODIFICATION HISTORY:
	'16Apr07    Azimuths are always positive (0-360 degrees)
	"""

	# Range:
	r_i = (x_i**2 + y_i**2 + z_i**2)**0.5

	# Azimuth:
	az_i = 90. - np.rad2deg( np.arctan2( y_i, x_i ) )

	# Elevation:
	el_i = np.rad2deg( np.arcsin( z_i / r_i ) )

	# Wrap negative azimuths 360 degrees around to positive:
	ii = np.where( az_i < 0. )[0]
	if len(ii) > 0:
		az_i[ii] += 360.

	# Return azimuth, elevation and range
	return  az_i, el_i, r_i


def mas_get_earth_radius( lat_i ):
    """Determines the earth's radius in meters at a given latitude(s) (degrees)
    using the WGS-84 parameters for the Earth's oblate spheroid surface.

    RESOURCE:
      http://en.wikipedia.org/wiki/Earth_radius#Radius_at_a_given_geodetic_latitude

    MODIFICATION HISTORY:
    '14Nov22        Created by Mark Stanley
    """

    # Earth's radius at the equator and the poles (with flattening factor f)
    a = 6378137.
    f = 1 / 298.257223563
    b = a * (1 - f)

    # Convert latitudes to radians
    latR_i = np.deg2rad( lat_i )

    # Calculate and return the radii
    radius_i = np.sqrt( ((a**2 * np.cos(latR_i))**2 + (b**2 * np.sin(latR_i))**2) / \
                        ((a * np.cos(latR_i))**2 + (b * np.sin(latR_i))**2) )

    return  radius_i


def mas_get_ECEF_from_geodetic( lat_i, lon_i, h_i ):
    """Determines the Earth Centered Earth Fixed (ECEF) cartesian coordinates
    from the provided geodetic latitude(s), longitude(s) and local height(s).
    The latitude(s) and longitude(s) are in degrees while local height should
    be in meters above mean sea level.  The result(s) are returned in units of
    meters as (X_i, Y_i, Z_i).

    RESOURCE:
      http://en.wikipedia.org/wiki/Geodetic_datum#From_geodetic_to_ECEF

    MODIFICATION HISTORY:
    '14Nov25        Created by Mark Stanley
    """

    # Earth's radius at the equator -and- first eccentricity squared
    a  = 6378137.
    e2 = 0.00669437999014

    # Convert lat/lon to radians
    latR_i = np.deg2rad( lat_i )
    lonR_i = np.deg2rad( lon_i )

    # Calculate the normal(s)
    Nr_i = a / np.sqrt( 1 - e2 * ( np.sin(latR_i) )**2 )

    # Calculate ECEF coordinates
    X_i = (Nr_i + h_i) * np.cos(latR_i) * np.cos(lonR_i)
    Y_i = (Nr_i + h_i) * np.cos(latR_i) * np.sin(lonR_i)
    Z_i = (Nr_i * (1 - e2) + h_i) * np.sin(latR_i)

    # Return result
    return  (X_i, Y_i, Z_i)


def mas_get_ENU_from_geodetic( lat_i, lon_i, h_i, latRef, lonRef, hRef ):
    """Determines the local x,y,z cartesian coordinates in the East (x),
    North (y) and Up (z) reference frame ('ENU'), given latitudes,
    longitudes and altitudes and a reference latitude, longitude and
    altitude.  The input lats/lons should be in degrees with the altitudes
    in meters above MSL.  The output are the local cartesian coordinates
    (xl_i, yl_i, zl_i) in units of meters.

    RESOURCE:
      http://en.wikipedia.org/wiki/Geodetic_datum#From_ECEF_to_ENU

    MODIFICATION HISTORY:
    '15Mar07        Created by Mark Stanley
    """

    # Obtain ECEF coordinates
    x_i,  y_i,  z_i  = mas_get_ECEF_from_geodetic( lat_i,  lon_i,  h_i )
    xRef, yRef, zRef = mas_get_ECEF_from_geodetic( latRef, lonRef, hRef )

    # Compute relative cartesian coordinates and form into a vector
    xDiff_i = x_i - xRef
    yDiff_i = y_i - yRef
    zDiff_i = z_i - zRef
    diff_i = np.array( [xDiff_i, yDiff_i, zDiff_i], dtype=np.float64 )

    # Determine reference lat/lon in radians
    latR = np.deg2rad( latRef )
    lonR = np.deg2rad( lonRef )

    # Rotation matrix for ECEF to ENU
    R_ij = np.matrix([[ -np.sin(lonR),  np.cos(lonR), 0. ], \
                      [-np.sin(latR) * np.cos(lonR), -np.sin(latR) * np.sin(lonR),\
                        np.cos(latR)], \
                      [ np.cos(latR) * np.cos(lonR),  np.cos(latR) * np.sin(lonR),\
                        np.sin(latR)]],  dtype=np.float64 )

    # Calculate ENU coordinates
    xl_i, yl_i, zl_i = np.asarray( np.dot( R_ij, diff_i ) )

    return (xl_i, yl_i, zl_i)


def mas_get_geodetic_from_ECEF( x_i, y_i, z_i ):
    """Determines the geodetic latitude(s), longitude(s) and local
    height(s) from the provided Earth Centered Earth Fixed (ECEF)
    cartesian x,y,z coordinates.  The cartesian coordinates should be
    in meters while the latitude(s) and longitude(s) will be output in
    degrees.  The local height will be in meters above mean sea
    level.

    USAGE:  lat_i, lon_i, h_i = mas_get_geodetic_from_ECEF( x_i, y_i, z_i )

    MODIFICATION HISTORY:
    '14Dec02        Created by Mark Stanley (using 'xy_to_lonlatxx.pro'
                     as a template)
    """

    # Earth's radius at the equator and the poles (with flattening factor f)
    a = 6378137.
    f = 1 / 298.257223563
    b = a * (1 - f)

    # Earth's first -and- second eccentricity squared
    e12  = 1 - (b/a)**2
    e22  = (a/b)**2 - 1

    # Coordinates needed for latitude conversion:
    p_i  = np.sqrt( x_i*x_i + y_i*y_i )
    th_i = np.arctan2( a*z_i, b*p_i )

    # Lat/lon in radians:
    latR_i = np.arctan2( (z_i + e22*b*(np.sin(th_i))**3), \
                      (p_i - e12*a*(np.cos(th_i))**3) )
    lonR_i = np.arctan2( y_i, x_i )

    # ...and in degrees
    lat_i = np.rad2deg( latR_i )
    lon_i = np.rad2deg( lonR_i )

    # Altitude MSL
    nr_i = a / np.sqrt( 1 - e12*(np.sin(latR_i))**2 )
    h_i  = p_i / np.cos( latR_i ) - nr_i

    return  lat_i, lon_i, h_i
